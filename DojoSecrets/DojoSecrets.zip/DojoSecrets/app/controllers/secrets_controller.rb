class SecretsController < ApplicationController
  def index
    render 'secrets'
  end

end
